package org.game.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/text")
public class MainServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle GET requests here
        response.setContentType("text/plain");
        response.getWriter().write("Привет Маке.");
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Получаем номер из запроса
        String number = request.getParameter("number");

        // Устанавливаем тип контента и отправляем ответ
        response.setContentType("text/html");
        response.getWriter().write("<html><body>");
        response.getWriter().write("<h2>Your number is: " + number + "</h2>");
        response.getWriter().write("<p>Вы ввели номер: " + number + "</p>"); // Обновленная фраза
        response.getWriter().write("</body></html>");
    }


}
